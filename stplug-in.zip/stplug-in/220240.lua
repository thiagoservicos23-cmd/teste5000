addappid(220240)
addappid(789,0,"testkey")
-- setManifestid(789,"789")